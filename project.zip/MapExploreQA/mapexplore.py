import webapp2
from google.appengine.ext import ndb

# Model for storing map information
class MapModel(ndb.Model):
    content = ndb.StringProperty(indexed=False)
    date = ndb.DateTimeProperty(auto_now_add=True)

class MainPage(webapp2.RequestHandler):
    def get(self):
    	self.response.headers.add_header("Access-Control-Allow-Origin", "*")
        mapModel = MapModel.get_by_id(self.request.get('Map'))
        self.response.write(mapModel.content)

class WritePage(webapp2.RequestHandler):
    def post(self):
    	self.response.headers.add_header("Access-Control-Allow-Origin", "*")
    	self.response.headers['Content-Type'] = 'text/plain'

    	# Retrieve map from datastore if it exists, else create a new one
        if MapModel.get_by_id(self.request.get('Map')):
        	newMap = MapModel.get_by_id(self.request.get('Map'))
        else:
            newMap = MapModel(id=self.request.get('Map'))

        newMap.content = self.request.body
        newMap.put()
        

application = webapp2.WSGIApplication([
    ('/', MainPage),
    ('/write', WritePage)
], debug=True)