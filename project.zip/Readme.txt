The project folder contains the frontend app and all the javascript source files etc. needed to run the application. 

The application is deployed to google app engine at http://mapexplore-qa.appspot.com/ so you don't actually need to run anything locally, but I included the source code so you can look at it if you want. 

If you want to look at the JSON produced by the app you can access it in a web browser with a url in the form of http://mapexplore-qa.appspot.com/?Map=[mapname], for instance, http://mapexplore-qa.appspot.com/?Map=Europa. 

At the top of app.js you will see all the map names and can change the URL if you feel like running it locally for some reason with google app engine. I made a separate deployment for the purposes of grading so you won't overwrite anything I'm using when you click save. 